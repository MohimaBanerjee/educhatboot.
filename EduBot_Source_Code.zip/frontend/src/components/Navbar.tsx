import { Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const scrollToChat = () => {
    document.getElementById("chat")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/70 backdrop-blur-xl border-b border-primary/30">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5" />
      <div className="container relative flex items-center justify-between h-16">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="absolute inset-0 bg-primary blur-md opacity-60 animate-neon-pulse" />
            <div className="relative h-9 w-9 flex items-center justify-center bg-background border border-primary clip-cyber">
              <Zap className="h-5 w-5 text-primary" strokeWidth={2.5} />
            </div>
          </div>
          <div>
            <span className="text-xl font-display font-black tracking-widest text-glow-pink">EDU<span className="text-accent text-glow-cyan">BOT</span></span>
            <div className="text-[9px] font-mono text-muted-foreground tracking-[0.3em] -mt-1">v.2.077 // ONLINE</div>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-xs font-mono uppercase tracking-widest text-muted-foreground hover:text-accent hover:text-glow-cyan transition-all">// Features</a>
          <a href="#how-it-works" className="text-xs font-mono uppercase tracking-widest text-muted-foreground hover:text-accent hover:text-glow-cyan transition-all">// Protocol</a>
          <a href="#chat" className="text-xs font-mono uppercase tracking-widest text-muted-foreground hover:text-accent hover:text-glow-cyan transition-all">// Interface</a>
        </div>
        <Button onClick={scrollToChat} size="sm" className="font-display tracking-widest uppercase clip-cyber bg-primary hover:bg-primary-glow text-primary-foreground neon-border-pink animate-neon-pulse">
          Jack In
        </Button>
      </div>
    </nav>
  );
};

export default Navbar;
