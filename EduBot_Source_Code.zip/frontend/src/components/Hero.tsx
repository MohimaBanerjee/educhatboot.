import { Button } from "@/components/ui/button";
import { Cpu, ArrowRight, Terminal } from "lucide-react";

const Hero = () => {
  const scrollToChat = () => {
    document.getElementById("chat")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Cyber grid background */}
      <div className="absolute inset-0 cyber-grid" />

      {/* Animated scanline */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-x-0 h-32 bg-gradient-to-b from-transparent via-accent/10 to-transparent animate-scanline" />
      </div>

      {/* Floating orbs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-primary/30 rounded-full blur-[120px] animate-float" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-accent/30 rounded-full blur-[120px] animate-float" style={{ animationDelay: "2s" }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-neon-violet/20 rounded-full blur-[150px]" />

      {/* Rotating ring */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] opacity-20 animate-spin-slow">
        <div className="absolute inset-0 border-2 border-dashed border-accent rounded-full" />
        <div className="absolute inset-8 border border-primary rounded-full" />
      </div>

      <div className="container relative z-10 text-center py-20">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-background/60 backdrop-blur-sm border border-accent/50 text-accent text-xs font-mono uppercase tracking-[0.3em] mb-8 opacity-0 animate-fade-in clip-cyber">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-accent" />
          </span>
          <Cpu className="h-3 w-3" />
          Neural.Link / ESTABLISHED
        </div>

        <h1 className="font-display font-black text-5xl md:text-7xl lg:text-8xl mb-8 max-w-5xl mx-auto leading-[0.95] tracking-tight opacity-0 animate-fade-in" style={{ animationDelay: "100ms" }}>
          <span className="block text-foreground text-glow-pink">HACK YOUR</span>
          <span className="block gradient-neon-text bg-[length:200%_auto] animate-gradient-shift" style={{ backgroundImage: "linear-gradient(90deg, hsl(315 100% 60%), hsl(270 100% 65%), hsl(180 100% 50%), hsl(315 100% 60%))" }}>
            EDUCATION
          </span>
          <span className="block text-accent text-glow-cyan text-3xl md:text-5xl lg:text-6xl mt-4 font-bold">// MATRIX_v.2077</span>
        </h1>

        <div className="font-mono text-sm md:text-base text-muted-foreground max-w-2xl mx-auto mb-10 opacity-0 animate-fade-in space-y-1" style={{ animationDelay: "200ms" }}>
          <div className="flex items-center justify-center gap-2 text-accent">
            <Terminal className="h-4 w-4" />
            <span>{">"} initializing neural_pathways...</span>
          </div>
          <p className="text-foreground/80">
            AI-driven academic interface. Instant knowledge extraction. <span className="text-primary text-glow-pink">Powered by NLP cores.</span> Available 24/7 across the grid.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 opacity-0 animate-fade-in" style={{ animationDelay: "300ms" }}>
          <Button size="lg" onClick={scrollToChat} className="group font-display tracking-widest uppercase text-base px-8 py-6 clip-cyber bg-primary hover:bg-primary-glow text-primary-foreground neon-border-pink animate-neon-pulse">
            Initiate Session <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button size="lg" variant="outline" asChild className="font-display tracking-widest uppercase text-base px-8 py-6 clip-cyber border-accent text-accent hover:bg-accent hover:text-accent-foreground neon-border-cyan bg-background/50 backdrop-blur-sm">
            <a href="#features">// View Specs</a>
          </Button>
        </div>

        {/* Stats bar */}
        <div className="mt-20 grid grid-cols-3 gap-4 max-w-3xl mx-auto opacity-0 animate-fade-in" style={{ animationDelay: "400ms" }}>
          {[
            { val: "99.7%", label: "Uptime", color: "text-accent text-glow-cyan" },
            { val: "<200ms", label: "Latency", color: "text-primary text-glow-pink" },
            { val: "∞", label: "Sessions", color: "text-neon-violet text-glow-violet" },
          ].map((s) => (
            <div key={s.label} className="bg-card/40 backdrop-blur-sm border border-border/50 p-4 clip-cyber">
              <div className={`font-display font-black text-2xl md:text-3xl ${s.color}`}>{s.val}</div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mt-1">// {s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
