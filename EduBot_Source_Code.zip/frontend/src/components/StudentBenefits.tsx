import { GraduationCap, Clock, Brain, Sparkles, Target, Shield } from "lucide-react";

const benefits = [
  {
    icon: Clock,
    title: "24/7 STUDY BUDDY",
    description: "No more waiting for office hours. Get instant help at 3 AM before that exam.",
    code: "// always.online",
    color: "primary",
  },
  {
    icon: Brain,
    title: "PERSONALIZED LEARNING",
    description: "Adapts to your level. Whether you're catching up or going advanced — it meets you there.",
    code: "// adaptive.mode",
    color: "accent",
  },
  {
    icon: Target,
    title: "EXAM-READY ANSWERS",
    description: "Concise, focused explanations that cut through the noise. Learn what actually matters.",
    code: "// precision.engaged",
    color: "neon-violet",
  },
  {
    icon: Sparkles,
    title: "SPARKS CURIOSITY",
    description: "Ask follow-ups, explore tangents, dive deep. Learning becomes a conversation, not a chore.",
    code: "// curiosity.unlocked",
    color: "primary",
  },
  {
    icon: Shield,
    title: "ZERO JUDGMENT ZONE",
    description: "Ask the 'dumb' questions. EduBot won't roll its eyes. Safe space to actually understand.",
    code: "// safe.protocol",
    color: "accent",
  },
  {
    icon: GraduationCap,
    title: "BOOST YOUR GRADES",
    description: "Better understanding, faster homework, sharper essays. Watch your GPA climb.",
    code: "// performance.+++",
    color: "neon-violet",
  },
];

const StudentBenefits = () => {
  return (
    <section id="benefits" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 cyber-grid opacity-20" />
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-accent/10 rounded-full blur-[150px]" />
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[150px]" />

      <div className="container relative">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-1.5 border border-accent/50 text-accent text-xs font-mono uppercase tracking-[0.3em] mb-6 clip-cyber bg-background/50">
            // STUDENT.PROTOCOL
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-black mb-4">
            <span className="text-foreground text-glow-pink">WHY STUDENTS </span>
            <span className="gradient-neon-text">LEVEL UP</span>
          </h2>
          <p className="font-mono text-sm text-muted-foreground max-w-2xl mx-auto">
            {">"} Six reasons EduBot is the unfair advantage every student deserves.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((benefit, i) => {
            const Icon = benefit.icon;
            const colorClass =
              benefit.color === "primary"
                ? "text-primary border-primary/50"
                : benefit.color === "accent"
                ? "text-accent border-accent/50"
                : "text-neon-violet border-neon-violet/50";

            return (
              <div
                key={i}
                className="group relative bg-card/60 backdrop-blur-sm border-2 border-primary/30 hover:border-primary p-6 clip-cyber transition-all duration-300 hover:scale-[1.02] opacity-0 animate-fade-in"
                style={{ animationDelay: `${i * 80}ms`, animationFillMode: "forwards" }}
              >
                <div className={`inline-flex p-3 border ${colorClass} mb-4 clip-cyber bg-background/50`}>
                  <Icon className="h-6 w-6" />
                </div>
                <div className={`font-mono text-[10px] tracking-[0.3em] mb-2 ${colorClass.split(" ")[0]}`}>
                  {benefit.code}
                </div>
                <h3 className="font-display text-xl font-bold mb-3 text-foreground tracking-wide">
                  {benefit.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default StudentBenefits;
