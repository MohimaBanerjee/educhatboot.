const steps = [
  { num: "01", title: "TRANSMIT.QUERY", desc: "Input your question into the neural interface using natural language.", color: "primary" },
  { num: "02", title: "NLP.PROCESS", desc: "Gemini AI cores parse, contextualize, and route your query through the grid.", color: "accent" },
  { num: "03", title: "RECEIVE.OUTPUT", desc: "Stream a precise, structured response in real-time. Knowledge unlocked.", color: "neon-violet" },
];

const HowItWorks = () => {
  return (
    <section id="how-it-works" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
      <div className="absolute inset-0 cyber-grid opacity-40" />

      <div className="container relative">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-1.5 border border-primary/50 text-primary text-xs font-mono uppercase tracking-[0.3em] mb-6 clip-cyber bg-background/50">
            // PROTOCOL.SEQUENCE
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-black">
            <span className="text-foreground text-glow-pink">HOW IT </span>
            <span className="gradient-neon-text">WORKS</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-16 left-[16%] right-[16%] h-px bg-gradient-to-r from-primary via-accent to-neon-violet opacity-50" />

          {steps.map((step, i) => {
            const colorMap = {
              primary: "text-primary text-glow-pink border-primary",
              accent: "text-accent text-glow-cyan border-accent",
              "neon-violet": "text-neon-violet text-glow-violet border-neon-violet",
            };
            const c = colorMap[step.color as keyof typeof colorMap];

            return (
              <div
                key={step.num}
                className="relative text-center opacity-0 animate-fade-in"
                style={{ animationDelay: `${i * 200}ms` }}
              >
                <div className={`relative mx-auto mb-6 h-32 w-32 flex items-center justify-center border-2 ${c.split(" ").filter(x => x.startsWith("border")).join(" ")} clip-cyber bg-background/80 backdrop-blur-sm animate-neon-pulse`}>
                  <div className={`font-display font-black text-5xl ${c.split(" ").filter(x => x.startsWith("text")).join(" ")}`}>
                    {step.num}
                  </div>
                </div>
                <h3 className={`font-display font-bold text-xl tracking-widest mb-3 ${c.split(" ").filter(x => x.startsWith("text")).join(" ")}`}>
                  {step.title}
                </h3>
                <p className="text-sm text-muted-foreground max-w-xs mx-auto font-sans">{step.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
