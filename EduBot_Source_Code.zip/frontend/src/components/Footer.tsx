import { Zap } from "lucide-react";

const Footer = () => (
  <footer className="relative py-12 border-t border-primary/30 overflow-hidden">
    <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent" />
    <div className="container relative flex flex-col md:flex-row items-center justify-between gap-6">
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="absolute inset-0 bg-primary blur-md opacity-60" />
          <div className="relative h-8 w-8 flex items-center justify-center bg-background border border-primary clip-cyber">
            <Zap className="h-4 w-4 text-primary" />
          </div>
        </div>
        <div>
          <span className="font-display font-black tracking-widest text-glow-pink">EDU<span className="text-accent text-glow-cyan">BOT</span></span>
          <div className="text-[9px] font-mono text-muted-foreground tracking-[0.3em]">// NEURAL.GRID.2077</div>
        </div>
      </div>
      <p className="text-xs font-mono text-muted-foreground tracking-wider text-center">
        {">"} BUILT_WITH: Python.AI + NLP.cores // EDUCATION_CHATBOT_PROJECT
      </p>
      <div className="text-[10px] font-mono text-accent tracking-widest">
        <span className="inline-block h-1.5 w-1.5 bg-accent rounded-full mr-2 animate-pulse" />
        SYS.STATUS: ONLINE
      </div>
    </div>
  </footer>
);

export default Footer;
