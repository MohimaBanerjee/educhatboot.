import { useState, useRef, useEffect } from "react";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;

async function streamChat({
  messages,
  onDelta,
  onDone,
  onError,
}: {
  messages: Message[];
  onDelta: (text: string) => void;
  onDone: () => void;
  onError: (error: string) => void;
}) {
  const resp = await fetch(CHAT_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
    },
    body: JSON.stringify({ messages }),
  });

  if (!resp.ok) {
    const data = await resp.json().catch(() => ({}));
    onError(data.error || `Request failed (${resp.status})`);
    return;
  }

  if (!resp.body) {
    onError("No response body");
    return;
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let newlineIndex: number;
    while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
      let line = buffer.slice(0, newlineIndex);
      buffer = buffer.slice(newlineIndex + 1);

      if (line.endsWith("\r")) line = line.slice(0, -1);
      if (line.startsWith(":") || line.trim() === "") continue;
      if (!line.startsWith("data: ")) continue;

      const jsonStr = line.slice(6).trim();
      if (jsonStr === "[DONE]") break;

      try {
        const parsed = JSON.parse(jsonStr);
        const content = parsed.choices?.[0]?.delta?.content;
        if (content) onDelta(content);
      } catch {
        buffer = line + "\n" + buffer;
        break;
      }
    }
  }

  onDone();
}

const ChatInterface = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMsg: Message = { role: "user", content: input.trim() };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput("");
    setIsLoading(true);

    let assistantContent = "";

    const updateAssistant = (chunk: string) => {
      assistantContent += chunk;
      setMessages((prev) => {
        const last = prev[prev.length - 1];
        if (last?.role === "assistant") {
          return prev.map((m, i) => (i === prev.length - 1 ? { ...m, content: assistantContent } : m));
        }
        return [...prev, { role: "assistant", content: assistantContent }];
      });
    };

    try {
      await streamChat({
        messages: updatedMessages,
        onDelta: updateAssistant,
        onDone: () => setIsLoading(false),
        onError: (error) => {
          toast({ title: "Error", description: error, variant: "destructive" });
          setIsLoading(false);
        },
      });
    } catch (e) {
      toast({ title: "Error", description: "Failed to connect to AI. Please try again.", variant: "destructive" });
      setIsLoading(false);
    }
  };

  return (
    <section id="chat" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 cyber-grid opacity-30" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/10 rounded-full blur-[150px]" />

      <div className="container relative max-w-3xl">
        <div className="text-center mb-10">
          <div className="inline-block px-4 py-1.5 border border-neon-violet/50 text-neon-violet text-xs font-mono uppercase tracking-[0.3em] mb-6 clip-cyber bg-background/50">
            // LIVE.TERMINAL
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-black mb-4">
            <span className="text-foreground text-glow-pink">JACK </span>
            <span className="gradient-neon-text">INTO EDUBOT</span>
          </h2>
          <p className="font-mono text-sm text-muted-foreground">
            {">"} Initiate handshake. Ask anything. Knowledge flows.
          </p>
        </div>

        <div className="relative bg-card/80 backdrop-blur-xl border-2 border-primary/60 clip-cyber neon-border-pink overflow-hidden">
          {/* Terminal header */}
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-primary/30 bg-background/80">
            <div className="flex items-center gap-2">
              <div className="h-2.5 w-2.5 rounded-full bg-destructive" />
              <div className="h-2.5 w-2.5 rounded-full bg-neon-lime" />
              <div className="h-2.5 w-2.5 rounded-full bg-accent" />
            </div>
            <div className="font-mono text-[10px] tracking-[0.3em] text-accent">
              EDUBOT.TERMINAL // SECURE.SESSION
            </div>
            <div className="font-mono text-[10px] text-muted-foreground flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 bg-neon-lime rounded-full animate-pulse" />
              REC
            </div>
          </div>

          <div ref={scrollRef} className="h-[28rem] overflow-y-auto p-5 space-y-4 bg-background/40">
            {messages.length === 0 && (
              <div className="flex justify-start opacity-0 animate-fade-in">
                <div className="max-w-[85%] px-5 py-3 border border-accent/60 bg-chat-bot/80 backdrop-blur-sm text-chat-bot-foreground text-sm leading-relaxed clip-cyber">
                  <div className="font-mono text-[10px] text-accent mb-1.5 tracking-widest">EDUBOT // SYS.MSG</div>
                  {">"} Greetings, operator. 👾 I am EduBot, your neural academic interface. Transmit any query — subjects, concepts, exam protocols. I am online.
                </div>
              </div>
            )}
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} opacity-0 animate-fade-in`}
              >
                <div
                  className={`max-w-[85%] px-5 py-3 text-sm leading-relaxed whitespace-pre-wrap clip-cyber ${
                    msg.role === "user"
                      ? "bg-primary/90 text-primary-foreground border border-primary"
                      : "bg-chat-bot/80 text-chat-bot-foreground border border-accent/60 backdrop-blur-sm"
                  }`}
                >
                  <div className={`font-mono text-[10px] mb-1.5 tracking-widest ${msg.role === "user" ? "text-primary-foreground/70" : "text-accent"}`}>
                    {msg.role === "user" ? "USER // INPUT" : "EDUBOT // OUTPUT"}
                  </div>
                  {msg.content}
                </div>
              </div>
            ))}
            {isLoading && messages[messages.length - 1]?.role !== "assistant" && (
              <div className="flex justify-start">
                <div className="bg-chat-bot/80 border border-accent/60 px-5 py-3 clip-cyber flex items-center gap-2">
                  <span className="font-mono text-[10px] text-accent tracking-widest mr-2">PROCESSING</span>
                  <span className="w-2 h-2 bg-accent rounded-full animate-typing" style={{ animationDelay: "0ms" }} />
                  <span className="w-2 h-2 bg-accent rounded-full animate-typing" style={{ animationDelay: "0.2s" }} />
                  <span className="w-2 h-2 bg-accent rounded-full animate-typing" style={{ animationDelay: "0.4s" }} />
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-primary/30 p-3 flex gap-2 bg-background/80">
            <div className="flex items-center font-mono text-accent text-sm pl-2">{">"}</div>
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="transmit_query..."
              className="flex-1 font-mono bg-background/60 border-accent/40 text-foreground placeholder:text-muted-foreground/50 focus-visible:ring-accent focus-visible:border-accent"
              disabled={isLoading}
            />
            <Button onClick={handleSend} size="icon" disabled={!input.trim() || isLoading} className="bg-primary hover:bg-primary-glow text-primary-foreground neon-border-pink clip-cyber">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChatInterface;
