import { BookOpen, Brain, Clock, MessageSquare, Sparkles, Users } from "lucide-react";

const features = [
  { icon: MessageSquare, title: "Instant.Response", description: "Zero-latency neural answers. No queue, no delay, no human bottleneck.", code: "RES_001", color: "primary" },
  { icon: Brain, title: "NLP.Core", description: "Advanced natural language parsing. Understands context across 100+ domains.", code: "NLP_002", color: "accent" },
  { icon: Clock, title: "24/7.Uplink", description: "Always-on grid presence. Learn from any timezone, any device, any moment.", code: "UPL_003", color: "neon-violet" },
  { icon: BookOpen, title: "Knowledge.Vault", description: "Vast subject coverage: code, math, science, exam protocols, and beyond.", code: "VLT_004", color: "accent" },
  { icon: Sparkles, title: "AI.Engine", description: "Powered by Gemini neural cores via Lovable Gateway. Pure intelligence.", code: "AIE_005", color: "primary" },
  { icon: Users, title: "Teacher.Augment", description: "Offload repetitive queries. Educators focus on what matters: real teaching.", code: "AUG_006", color: "neon-violet" },
];

const Features = () => {
  return (
    <section id="features" className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 cyber-grid opacity-50" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent/20 rounded-full blur-[120px]" />

      <div className="container relative">
        <div className="text-center mb-20">
          <div className="inline-block px-4 py-1.5 border border-accent/50 text-accent text-xs font-mono uppercase tracking-[0.3em] mb-6 clip-cyber bg-background/50">
            // SYSTEM.SPECS
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-black mb-6">
            <span className="gradient-neon-text">WHY EDUBOT?</span>
          </h2>
          <p className="font-mono text-sm text-muted-foreground max-w-2xl mx-auto">
            {">"} Built on Python_AI + NLP_protocols. Engineered for next-gen learners.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => {
            const colorClass = feature.color === "primary" ? "text-primary text-glow-pink border-primary/40 hover:border-primary"
              : feature.color === "accent" ? "text-accent text-glow-cyan border-accent/40 hover:border-accent"
              : "text-neon-violet text-glow-violet border-neon-violet/40 hover:border-neon-violet";

            return (
              <div
                key={feature.title}
                className={`group relative bg-card/60 backdrop-blur-sm border-2 ${colorClass.split(" ").filter(c => c.startsWith("border")).join(" ")} clip-cyber p-6 transition-all duration-300 hover:-translate-y-1 opacity-0 animate-fade-in`}
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div className="absolute top-3 right-3 font-mono text-[10px] tracking-widest text-muted-foreground/60">
                  [{feature.code}]
                </div>

                <div className={`h-14 w-14 flex items-center justify-center mb-5 border-2 ${colorClass.split(" ").filter(c => c.startsWith("border")).join(" ")} clip-cyber bg-background/80 group-hover:animate-neon-pulse`}>
                  <feature.icon className={`h-6 w-6 ${colorClass.split(" ").filter(c => c.startsWith("text")).join(" ")}`} strokeWidth={2} />
                </div>

                <h3 className={`font-display font-bold text-xl mb-3 tracking-wide ${colorClass.split(" ").filter(c => c.startsWith("text")).join(" ")}`}>
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed font-sans">
                  {feature.description}
                </p>

                <div className="absolute bottom-0 left-0 h-0.5 w-0 group-hover:w-full bg-gradient-to-r from-primary via-accent to-neon-violet transition-all duration-500" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;
