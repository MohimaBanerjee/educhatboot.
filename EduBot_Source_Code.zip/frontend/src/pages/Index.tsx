import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import HowItWorks from "@/components/HowItWorks";
import ChatInterface from "@/components/ChatInterface";
import StudentBenefits from "@/components/StudentBenefits";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <Features />
      <HowItWorks />
      <ChatInterface />
      <StudentBenefits />
      <Footer />
    </div>
  );
};

export default Index;
