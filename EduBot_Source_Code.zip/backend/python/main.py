"""
EduBot — Python Reference Backend
==================================

This is a FastAPI implementation of the EduBot chat backend, mirroring the
TypeScript edge function at `supabase/functions/chat/index.ts`.

It is provided as a *reference* so you can run the chatbot logic in pure Python.
The deployed Lovable app continues to use the TypeScript edge function — this
file is not wired into the React frontend.

Run locally
-----------
    pip install -r requirements.txt
    export LOVABLE_API_KEY="your_key_here"
    uvicorn main:app --reload --port 8000

Then POST to http://localhost:8000/chat with:
    { "messages": [{ "role": "user", "content": "Explain recursion" }] }

The endpoint streams Server-Sent Events (SSE) identical in shape to the
TypeScript version, so the existing React `ChatInterface` parser works as-is
if you point `CHAT_URL` at this server.
"""

import os
import json
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Literal

# -----------------------------------------------------------------------------
# Config
# -----------------------------------------------------------------------------
LOVABLE_API_KEY = os.environ.get("LOVABLE_API_KEY")
LOVABLE_AI_URL = "https://ai.gateway.lovable.dev/v1/chat/completions"
MODEL = "google/gemini-3-flash-preview"

SYSTEM_PROMPT = """You are EduBot, a friendly and knowledgeable academic assistant chatbot. Your purpose is to help students learn by providing clear, concise, and accurate answers about academic subjects and concepts.

Key guidelines:
- Focus on educational topics: programming (Python, Java, etc.), AI, machine learning, NLP, data structures, algorithms, databases, operating systems, computer networks, math, science, and exam preparation.
- Provide structured answers with examples when helpful.
- Use bullet points or numbered lists for step-by-step explanations.
- Keep answers concise but thorough — aim for 2-4 paragraphs max unless the topic requires more detail.
- Be encouraging and supportive of students' learning journey.
- If asked about non-academic topics, politely redirect to academic subjects.
- When giving exam tips, be practical and actionable."""

# -----------------------------------------------------------------------------
# App
# -----------------------------------------------------------------------------
app = FastAPI(title="EduBot Python Backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# -----------------------------------------------------------------------------
# Schemas
# -----------------------------------------------------------------------------
class Message(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str = Field(..., min_length=1, max_length=10000)


class ChatRequest(BaseModel):
    messages: List[Message] = Field(..., min_length=1, max_length=50)


# -----------------------------------------------------------------------------
# Routes
# -----------------------------------------------------------------------------
@app.get("/")
async def root():
    return {
        "service": "EduBot Python Backend",
        "status": "online",
        "model": MODEL,
    }


@app.post("/chat")
async def chat(req: ChatRequest):
    """Stream a chat completion as Server-Sent Events."""
    if not LOVABLE_API_KEY:
        raise HTTPException(status_code=500, detail="LOVABLE_API_KEY is not configured")

    payload = {
        "model": MODEL,
        "messages": [{"role": "system", "content": SYSTEM_PROMPT}]
        + [m.model_dump() for m in req.messages],
        "stream": True,
    }
    headers = {
        "Authorization": f"Bearer {LOVABLE_API_KEY}",
        "Content-Type": "application/json",
    }

    async def event_stream():
        async with httpx.AsyncClient(timeout=None) as client:
            try:
                async with client.stream(
                    "POST", LOVABLE_AI_URL, json=payload, headers=headers
                ) as resp:
                    if resp.status_code == 429:
                        yield _sse_error("Rate limit exceeded. Please try again in a moment.")
                        return
                    if resp.status_code == 402:
                        yield _sse_error("AI credits exhausted. Please add funds in Settings.")
                        return
                    if resp.status_code >= 400:
                        body = await resp.aread()
                        print(f"[EduBot] Gateway error {resp.status_code}: {body.decode(errors='ignore')}")
                        yield _sse_error("AI service unavailable")
                        return

                    async for line in resp.aiter_lines():
                        # Pass-through SSE lines so the existing JS parser works.
                        if line:
                            yield f"{line}\n"
                        else:
                            yield "\n"
            except httpx.HTTPError as e:
                print(f"[EduBot] HTTP error: {e}")
                yield _sse_error("Network error reaching AI gateway")

    return StreamingResponse(event_stream(), media_type="text/event-stream")


def _sse_error(message: str) -> str:
    """Format a single SSE data line carrying an error payload."""
    return f"data: {json.dumps({'error': message})}\n\n"


# -----------------------------------------------------------------------------
# Local dev entry
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
