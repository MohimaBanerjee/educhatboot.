# EduBot — Python Reference Backend

A **FastAPI** implementation of the EduBot chat backend, mirroring the TypeScript edge function in `supabase/functions/chat/index.ts`.

> ℹ️ This is a *reference implementation*. The live Lovable app uses the TypeScript edge function. Use this if you want to run / extend the backend in pure Python.

## Stack

- **FastAPI** — async web framework
- **httpx** — async HTTP client (streams responses)
- **Pydantic v2** — request validation
- **Lovable AI Gateway** — calls `google/gemini-3-flash-preview`

## Setup

```bash
cd python-backend
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

export LOVABLE_API_KEY="your_lovable_ai_key"
uvicorn main:app --reload --port 8000
```

## Endpoints

### `GET /`
Health check.

### `POST /chat`
Streams a chat completion as **Server-Sent Events** (SSE), identical to the TS version.

**Request body**
```json
{
  "messages": [
    { "role": "user", "content": "Explain Big-O notation" }
  ]
}
```

**Response** — `text/event-stream` with OpenAI-style SSE chunks:
```
data: {"choices":[{"delta":{"content":"Big"}}]}
data: {"choices":[{"delta":{"content":"-O"}}]}
data: [DONE]
```

## Wiring it into the React frontend (optional)

The existing `ChatInterface.tsx` parser is fully compatible. To point it at this Python server instead of the edge function, change `CHAT_URL` in `src/components/ChatInterface.tsx`:

```ts
const CHAT_URL = "http://localhost:8000/chat";
```

(And remove the `Authorization` header, or update it to whatever auth scheme you add.)

## Notes vs. the TypeScript edge function

| Feature | TS edge function | Python backend |
|---|---|---|
| Runtime | Deno | Python 3.10+ |
| Web framework | `std/http` | FastAPI |
| Validation | Manual | Pydantic |
| Streaming | Pass-through `Response.body` | `httpx.stream` + async generator |
| Same SSE format | ✅ | ✅ |
| Same system prompt | ✅ | ✅ |
| Same model | ✅ | ✅ |
