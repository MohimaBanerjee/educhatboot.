# EduBot — Core Source Bundle

This bundle contains the core frontend and backend code for the EduBot academic chatbot.

## Structure

```
edubot-bundle/
├── frontend/              # React + Vite + TypeScript + Tailwind
│   ├── src/
│   │   ├── components/    # ChatInterface, Hero, Features, etc.
│   │   ├── pages/         # Index page
│   │   ├── hooks/         # use-toast, use-mobile
│   │   ├── lib/           # utils
│   │   ├── integrations/supabase/client.ts
│   │   ├── App.tsx, main.tsx, index.css
│   ├── package.json, vite.config.ts, tailwind.config.ts, etc.
│
└── backend/
    ├── edge-function/     # Deno-based Supabase edge function (LIVE backend)
    │   └── index.ts       # Deploy to supabase/functions/chat/
    └── python/            # FastAPI reference backend
        ├── main.py
        ├── requirements.txt
        └── README.md
```

## Frontend setup

```bash
cd frontend
npm install
# Create .env with:
#   VITE_SUPABASE_URL=...
#   VITE_SUPABASE_PUBLISHABLE_KEY=...
npm run dev
```

## Backend — Option A: Supabase Edge Function (Deno)

Place `backend/edge-function/index.ts` at `supabase/functions/chat/index.ts` and deploy:
```bash
supabase functions deploy chat
supabase secrets set LOVABLE_API_KEY=your_key
```

## Backend — Option B: Python (FastAPI)

```bash
cd backend/python
pip install -r requirements.txt
export LOVABLE_API_KEY=your_key
uvicorn main:app --reload --port 8000
```

To use the Python backend, change `CHAT_URL` in `frontend/src/components/ChatInterface.tsx`:
```ts
const CHAT_URL = "http://localhost:8000/chat";
```

## Tech Stack
- **Frontend:** React 18, Vite, TypeScript, Tailwind CSS, shadcn/ui
- **Backend (live):** Deno edge function on Supabase
- **Backend (reference):** Python 3.10+, FastAPI, httpx
- **AI:** Lovable AI Gateway → google/gemini-3-flash-preview (SSE streaming)
